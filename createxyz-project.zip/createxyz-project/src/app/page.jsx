"use client";
import React from "react";

function MainComponent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortBy, setSortBy] = useState("popularity");
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [wishlist, setWishlist] = useState([]);
  const [brandFilter, setBrandFilter] = useState("all");
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [currentPage, setCurrentPage] = useState("home");
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [showSearchResults, setShowSearchResults] = useState(false);
  const categories = [
    "Smartphones",
    "Laptops",
    "Tablets",
    "Smartwatches",
    "Headphones",
  ];
  const brands = ["Apple", "Samsung", "Google", "Sony", "Dell", "HP"];
  const sampleProducts = [
    {
      id: 1,
      name: "iPhone 14 Pro",
      category: "Smartphones",
      brand: "Apple",
      price: 999,
      rating: 4.8,
      reviews: 1250,
      image: "/images/iphone-14-pro.jpg",
      features: ["A16 Bionic Chip", "48MP Camera", "Dynamic Island"],
      specs: {
        "Screen Size": "6.1 inch",
        Storage: "128GB",
        Battery: "3200mAh",
      },
      valueRatings: {
        performance: "High",
        camera: "High",
        battery: "Medium",
        price: "Medium",
      },
    },
    {
      id: 2,
      name: "Samsung Galaxy S23 Ultra",
      category: "Smartphones",
      brand: "Samsung",
      price: 1199,
      rating: 4.7,
      reviews: 980,
      image: "/images/galaxy-s23-ultra.jpg",
      features: ["200MP Camera", "S Pen", "8K Video"],
      specs: {
        "Screen Size": "6.8 inch",
        Storage: "256GB",
        Battery: "5000mAh",
      },
      valueRatings: {
        performance: "High",
        camera: "High",
        battery: "High",
        price: "Medium",
      },
    },
    {
      id: 3,
      name: "MacBook Pro 16",
      category: "Laptops",
      brand: "Apple",
      price: 2499,
      rating: 4.9,
      reviews: 756,
      image: "/images/macbook-pro-16.jpg",
      features: ["M2 Max Chip", "Liquid Retina XDR", "Up to 96GB RAM"],
      specs: {
        "Screen Size": "16 inch",
        Storage: "512GB",
        RAM: "32GB",
      },
      valueRatings: {
        performance: "High",
        display: "High",
        battery: "High",
        price: "High",
      },
    },
  ];
  const handlePriceChange = (type, value) => {
    if (type === "min") {
      setMinPrice(value);
    } else {
      setMaxPrice(value);
    }
  };
  const handleProductClick = (product) => {
    setSelectedProduct(product);
    setCurrentPage("product-detail");
    setShowSearchResults(false);
    setSearchTerm("");
  };
  const toggleWishlist = (productId) => {
    setWishlist((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };
  const handleCompare = (product) => {
    setSelectedProducts((current) => {
      if (current.find((p) => p.id === product.id)) {
        return current.filter((p) => p.id !== product.id);
      }
      if (current.length === 0) {
        return [product];
      }
      if (product.category !== current[0].category) {
        alert("You can only compare products from the same category!");
        return current;
      }
      if (current.length < 3) {
        return [...current, product];
      }
      return current;
    });
  };
  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    setSelectedProducts([]);
    setCurrentPage("products");
    setShowSearchResults(false);
    setSearchTerm("");
  };
  const handleLogin = (email, password) => {
    if (email === "admin@techcompare.com" && password === "admin123") {
      setIsLoggedIn(true);
      setIsAdmin(true);
      setUserEmail(email);
      setShowAuthModal(false);
    }
  };
  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsAdmin(false);
    setUserEmail("");
  };
  const sortProducts = (products) => {
    switch (sortBy) {
      case "price-low":
        return [...products].sort((a, b) => a.price - b.price);
      case "price-high":
        return [...products].sort((a, b) => b.price - a.price);
      case "rating":
        return [...products].sort((a, b) => b.rating - a.rating);
      default:
        return [...products].sort((a, b) => b.reviews - a.reviews);
    }
  };
  const filteredProducts = sortProducts(
    sampleProducts.filter((product) => {
      const matchesSearch = product.name
        .toLowerCase()
        .includes(searchTerm.toLowerCase());
      const matchesCategory =
        selectedCategory === "all" || product.category === selectedCategory;
      const matchesBrand =
        brandFilter === "all" || product.brand === brandFilter;
      const matchesPrice =
        (!minPrice || product.price >= Number(minPrice)) &&
        (!maxPrice || product.price <= Number(maxPrice));

      return matchesSearch && matchesCategory && matchesBrand && matchesPrice;
    })
  );
  const handleSearchFocus = () => {
    setShowSearchResults(true);
  };
  const handleSearchBlur = () => {
    // Delay hiding results to allow for click events
    setTimeout(() => {
      setShowSearchResults(false);
    }, 200);
  };
  const renderHeader = () => (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <button
              onClick={() => setCurrentPage("home")}
              className="text-2xl font-bold text-gray-900 font-poppins hover:text-blue-600"
            >
              TechBuyWay
            </button>
          </div>

          <nav className="hidden md:flex space-x-8 mx-8">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => handleCategoryChange(category)}
                className={`text-sm font-medium ${
                  selectedCategory === category
                    ? "text-blue-600 border-b-2 border-blue-600"
                    : "text-gray-500 hover:text-gray-900"
                }`}
              >
                {category}
              </button>
            ))}
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            {isAdmin && (
              <button
                onClick={() => setCurrentPage("admin")}
                className="p-2 rounded-full hover:bg-gray-100"
              >
                <i className="fas fa-cog text-gray-600"></i>
              </button>
            )}
            <button className="p-2 rounded-full hover:bg-gray-100">
              <i className="far fa-heart text-gray-600"></i>
            </button>
            {isLoggedIn ? (
              <div className="relative group">
                <button className="p-2 rounded-full hover:bg-gray-100 flex items-center">
                  <span className="mr-2">{userEmail}</span>
                  <i className="far fa-user text-gray-600"></i>
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden group-hover:block">
                  <button
                    onClick={handleLogout}
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
                  >
                    Sign Out
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setShowAuthModal(true)}
                className="p-2 rounded-full hover:bg-gray-100"
              >
                <i className="far fa-user text-gray-600"></i>
              </button>
            )}
          </div>

          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <i
              className={`fas ${
                isMenuOpen ? "fa-times" : "fa-bars"
              } text-gray-600`}
            ></i>
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4">
            <nav className="space-y-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => {
                    handleCategoryChange(category);
                    setIsMenuOpen(false);
                  }}
                  className={`block w-full text-left px-4 py-2 text-sm ${
                    selectedCategory === category
                      ? "text-blue-600 bg-blue-50"
                      : "text-gray-500 hover:bg-gray-50"
                  }`}
                >
                  {category}
                </button>
              ))}
            </nav>
            <div className="mt-4 pt-4 border-t border-gray-200">
              {isLoggedIn ? (
                <button
                  onClick={handleLogout}
                  className="block w-full text-left px-4 py-2 text-sm text-gray-500 hover:bg-gray-50"
                >
                  Sign Out
                </button>
              ) : (
                <button
                  onClick={() => {
                    setShowAuthModal(true);
                    setIsMenuOpen(false);
                  }}
                  className="block w-full text-left px-4 py-2 text-sm text-gray-500 hover:bg-gray-50"
                >
                  Sign In
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
  const renderHomePage = () => (
    <div className="w-full">
      <div className="relative w-full h-[500px] bg-[#FAFAFA]">
        <div className="relative max-w-7xl mx-auto py-16 px-4 flex flex-col items-center justify-center h-full text-center">
          <h1 className="text-3xl md:text-5xl font-bold text-[#1A1A1A] mb-6">
            Find the Best Tech Deals
          </h1>
          <p className="text-base md:text-lg text-[#666666] mb-8 max-w-2xl">
            Compare prices and specifications across multiple stores to make
            informed decisions on your tech purchases.
          </p>
          <div className="w-full max-w-lg">
            <div className="relative">
              <input
                type="text"
                placeholder="Search for products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onFocus={handleSearchFocus}
                onBlur={handleSearchBlur}
                className="w-full px-4 py-3 rounded-lg bg-white border border-gray-200 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              {searchTerm &&
                showSearchResults &&
                filteredProducts.length > 0 && (
                  <div className="absolute mt-1 w-full bg-white rounded-lg shadow-lg border border-gray-200 z-50 max-h-[400px] overflow-y-auto">
                    <div className="sticky top-0 bg-gray-50 p-3 border-b border-gray-200">
                      <p className="text-sm text-gray-600">
                        Found {filteredProducts.length} results
                      </p>
                    </div>
                    {filteredProducts.map((product) => (
                      <div
                        key={product.id}
                        className="p-4 hover:bg-gray-50 cursor-pointer border-b border-gray-100 flex justify-between items-center"
                        onClick={() => handleProductClick(product)}
                      >
                        <div className="flex items-center space-x-4">
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-12 h-12 object-cover rounded"
                          />
                          <div>
                            <div className="font-medium">{product.name}</div>
                            <div className="text-sm text-gray-500">
                              {product.category} • ${product.price}
                            </div>
                          </div>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleCompare(product);
                          }}
                          className={`px-3 py-1 rounded text-sm ${
                            selectedProducts.find((p) => p.id === product.id)
                              ? "bg-green-500 text-white"
                              : "border border-gray-300 hover:bg-gray-50"
                          }`}
                        >
                          {selectedProducts.find((p) => p.id === product.id)
                            ? "Added"
                            : "Compare"}
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              <button className="absolute right-3 top-1/2 transform -translate-y-1/2">
                <i className="fas fa-search text-gray-400"></i>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-16">
        <h2 className="text-2xl font-bold text-center mb-12">
          Browse Categories
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
          {categories.map((category) => {
            const icons = {
              Laptops: "fas fa-laptop",
              Smartphones: "fas fa-mobile-alt",
              Tablets: "fas fa-tablet-alt",
              Smartwatches: "fas fa-stopwatch",
              Headphones: "fas fa-headphones",
            };

            return (
              <button
                key={category}
                onClick={() => handleCategoryChange(category)}
                className="flex flex-col items-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="w-16 h-16 flex items-center justify-center bg-blue-50 rounded-full mb-4">
                  <i
                    className={`${icons[category]} text-2xl text-blue-600`}
                  ></i>
                </div>
                <span className="text-gray-900 font-medium text-center">
                  {category}
                </span>
              </button>
            );
          })}
        </div>

        <div className="mt-20">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Featured Products
            </h2>
            <p className="text-xl text-gray-600">
              Compare the latest and most popular tech products
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {sampleProducts.map((product) => (
              <div
                key={product.id}
                className="group bg-white rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden transform hover:-translate-y-1"
              >
                <div className="relative h-72 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300">
                    <div className="absolute bottom-4 left-4 right-4 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                      <p className="text-white text-lg font-semibold truncate">
                        {product.name}
                      </p>
                      <div className="flex items-center text-white/90 text-sm mt-2">
                        <div className="flex items-center">
                          {[...Array.from({ length: 5 })].map((_, i) => (
                            <i
                              key={i}
                              className={`${
                                i < Math.floor(product.rating) ? "fas" : "far"
                              } fa-star ${
                                i < Math.floor(product.rating)
                                  ? "text-yellow-400"
                                  : "text-gray-400"
                              }`}
                            ></i>
                          ))}
                        </div>
                        <span className="ml-2">
                          ({product.reviews} reviews)
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-2xl font-bold text-blue-600 ml-4">
                      ${product.price}
                    </p>
                  </div>
                  <div className="space-y-3 mb-6">
                    {product.features.slice(0, 2).map((feature, index) => (
                      <div
                        key={index}
                        className="flex items-center text-gray-600"
                      >
                        <i className="fas fa-check text-green-500 mr-3"></i>
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-4">
                    <button
                      onClick={() => handleProductClick(product)}
                      className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors transform hover:scale-[1.02]"
                    >
                      View Details
                    </button>
                    <button
                      onClick={() => handleCompare(product)}
                      className="px-4 py-3 border-2 border-gray-200 rounded-lg hover:border-blue-600 hover:text-blue-600 transition-all transform hover:scale-[1.02]"
                    >
                      <i className="fas fa-exchange-alt"></i>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
  const renderProductsPage = () => (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        <aside className="w-full md:w-64 bg-white p-6 rounded-lg shadow-sm h-fit">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Filters</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sort by
              </label>
              <select
                name="sortBy"
                className="w-full border border-gray-300 rounded-md p-2"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
              >
                <option value="popularity">Popularity</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Rating</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Brand
              </label>
              <select
                name="brandFilter"
                className="w-full border border-gray-300 rounded-md p-2"
                value={brandFilter}
                onChange={(e) => setBrandFilter(e.target.value)}
              >
                <option value="all">All Brands</option>
                {brands.map((brand) => (
                  <option key={brand} value={brand}>
                    {brand}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Price Range
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  name="min-price"
                  placeholder="Min"
                  value={minPrice}
                  onChange={(e) => handlePriceChange("min", e.target.value)}
                  className="w-full border border-gray-300 rounded-md p-2"
                />
                <span>-</span>
                <input
                  type="number"
                  name="max-price"
                  placeholder="Max"
                  value={maxPrice}
                  onChange={(e) => handlePriceChange("max", e.target.value)}
                  className="w-full border border-gray-300 rounded-md p-2"
                />
              </div>
            </div>
          </div>
        </aside>

        <div className="flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover rounded mb-4"
                />
                <h3 className="text-lg font-semibold mb-2">{product.name}</h3>
                <p className="text-gray-600 mb-2">${product.price}</p>
                <div className="flex items-center mb-4">
                  {[...Array.from({ length: 5 })].map((_, i) => (
                    <i
                      key={i}
                      className={`${
                        i < Math.floor(product.rating) ? "fas" : "far"
                      } fa-star text-yellow-400`}
                    ></i>
                  ))}
                  <span className="ml-2 text-sm text-gray-600">
                    ({product.reviews})
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <button
                    onClick={() => handleCompare(product)}
                    className={`px-4 py-2 rounded ${
                      selectedProducts.find((p) => p.id === product.id)
                        ? "bg-green-500 hover:bg-green-600"
                        : "bg-blue-500 hover:bg-blue-600"
                    } text-white`}
                  >
                    {selectedProducts.find((p) => p.id === product.id)
                      ? "Remove"
                      : "Compare"}
                  </button>
                  <button
                    onClick={() => toggleWishlist(product.id)}
                    className="p-2 text-gray-500 hover:text-red-500"
                  >
                    <i
                      className={`${
                        wishlist.includes(product.id) ? "fas" : "far"
                      } fa-heart`}
                    ></i>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
  const renderProductDetail = () => (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button
        onClick={() => setCurrentPage("products")}
        className="mb-8 flex items-center text-blue-600 hover:text-blue-700"
      >
        <i className="fas fa-arrow-left mr-2"></i>
        Back to Products
      </button>

      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <img
              src={selectedProduct.image}
              alt={selectedProduct.name}
              className="w-full h-96 object-cover rounded-lg"
            />
          </div>

          <div>
            <h1 className="text-3xl font-bold mb-4">{selectedProduct.name}</h1>
            <div className="flex items-center mb-4">
              <div className="flex items-center">
                {[...Array.from({ length: 5 })].map((_, i) => (
                  <i
                    key={i}
                    className={`${
                      i < Math.floor(selectedProduct.rating) ? "fas" : "far"
                    } fa-star text-yellow-400`}
                  ></i>
                ))}
              </div>
              <span className="ml-2 text-gray-600">
                ({selectedProduct.reviews} reviews)
              </span>
            </div>

            <p className="text-3xl font-bold text-blue-600 mb-6">
              ${selectedProduct.price}
            </p>

            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold mb-3">Features</h2>
                <ul className="list-disc list-inside space-y-2">
                  {selectedProduct.features.map((feature, index) => (
                    <li key={index} className="text-gray-600">
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h2 className="text-xl font-semibold mb-3">Specifications</h2>
                <dl className="space-y-2">
                  {Object.entries(selectedProduct.specs).map(([key, value]) => (
                    <div key={key} className="flex justify-between">
                      <dt className="text-gray-600">{key}</dt>
                      <dd className="font-medium">{value}</dd>
                    </div>
                  ))}
                </dl>
              </div>

              <div>
                <h2 className="text-xl font-semibold mb-3">Value Ratings</h2>
                {Object.entries(selectedProduct.valueRatings).map(
                  ([key, value]) => (
                    <div key={key} className="mb-4">
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium capitalize">
                          {key}
                        </span>
                        <span className="text-sm text-gray-500">{value}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${
                            value === "High"
                              ? "bg-green-500 w-full"
                              : value === "Medium"
                              ? "bg-yellow-500 w-2/3"
                              : "bg-red-500 w-1/3"
                          }`}
                        ></div>
                      </div>
                    </div>
                  )
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
  const renderComparison = () => (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button
        onClick={() => setCurrentPage("products")}
        className="mb-8 flex items-center text-blue-600 hover:text-blue-700"
      >
        <i className="fas fa-arrow-left mr-2"></i>
        Back to Products
      </button>

      <div className="bg-white rounded-lg shadow-sm p-8">
        <h1 className="text-3xl font-bold mb-8">Product Comparison</h1>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Feature
                </th>
                {selectedProducts.map((product) => (
                  <th
                    key={product.id}
                    className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    {product.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  Price
                </td>
                {selectedProducts.map((product) => (
                  <td
                    key={product.id}
                    className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"
                  >
                    ${product.price}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  Rating
                </td>
                {selectedProducts.map((product) => (
                  <td
                    key={product.id}
                    className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"
                  >
                    {product.rating}/5 ({product.reviews} reviews)
                  </td>
                ))}
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  Features
                </td>
                {selectedProducts.map((product) => (
                  <td
                    key={product.id}
                    className="px-6 py-4 text-sm text-gray-500"
                  >
                    <ul className="list-disc list-inside">
                      {product.features.map((feature, index) => (
                        <li key={index}>{feature}</li>
                      ))}
                    </ul>
                  </td>
                ))}
              </tr>
              {Object.keys(selectedProducts[0].specs).map((specKey) => (
                <tr key={specKey}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {specKey}
                  </td>
                  {selectedProducts.map((product) => (
                    <td
                      key={product.id}
                      className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"
                    >
                      {product.specs[specKey]}
                    </td>
                  ))}
                </tr>
              ))}
              <tr>
                <td className="px-6 py-4 text-sm font-medium text-gray-900">
                  Value Ratings
                </td>
                {selectedProducts.map((product) => (
                  <td key={product.id} className="px-6 py-4">
                    {Object.entries(product.valueRatings).map(
                      ([key, value]) => (
                        <div key={key} className="mb-4">
                          <div className="flex justify-between mb-1">
                            <span className="text-sm capitalize">{key}</span>
                            <span className="text-sm text-gray-500">
                              {value}
                            </span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full ${
                                value === "High"
                                  ? "bg-green-500 w-full"
                                  : value === "Medium"
                                  ? "bg-yellow-500 w-2/3"
                                  : "bg-red-500 w-1/3"
                              }`}
                            ></div>
                          </div>
                        </div>
                      )
                    )}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
  const renderAdminPanel = () => (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button
        onClick={() => setCurrentPage("products")}
        className="mb-8 flex items-center text-blue-600 hover:text-blue-700"
      >
        <i className="fas fa-arrow-left mr-2"></i>
        Back to Products
      </button>

      <div className="bg-white rounded-lg shadow-sm p-8">
        <h1 className="text-3xl font-bold mb-8">Admin Panel</h1>

        <div className="space-y-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Product Management</h2>
            <button className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
              Add New Product
            </button>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-4">Existing Products</h2>
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Product
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Category
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Price
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {sampleProducts.map((product) => (
                  <tr key={product.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          <img
                            className="h-10 w-10 rounded-full object-cover"
                            src={product.image}
                            alt={product.name}
                          />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {product.name}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {product.category}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        ${product.price}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button className="text-blue-600 hover:text-blue-900 mr-4">
                        Edit
                      </button>
                      <button className="text-red-600 hover:text-red-900">
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {renderHeader()}

      <main className="flex-1">
        {currentPage === "home" && renderHomePage()}
        {currentPage === "products" && renderProductsPage()}
        {currentPage === "product-detail" &&
          selectedProduct &&
          renderProductDetail()}
        {currentPage === "comparison" &&
          selectedProducts.length > 0 &&
          renderComparison()}
        {currentPage === "admin" && isAdmin && renderAdminPanel()}
      </main>

      {selectedProducts.length > 0 && currentPage !== "comparison" && (
        <div className="fixed bottom-0 left-0 right-0 bg-white shadow-lg border-t border-gray-200 p-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-4">
              {selectedProducts.map((product) => (
                <div key={product.id} className="flex items-center gap-2">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-12 h-12 object-cover rounded"
                  />
                  <button
                    onClick={() => handleCompare(product)}
                    className="text-red-500 hover:text-red-600"
                  >
                    <i className="fas fa-times"></i>
                  </button>
                </div>
              ))}
            </div>
            <button
              onClick={() => setCurrentPage("comparison")}
              className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600"
            >
              Compare {selectedProducts.length} Products
            </button>
          </div>
        </div>
      )}

      {showAuthModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg w-full max-w-md">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold">Sign In</h2>
              <button
                onClick={() => setShowAuthModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                const email = e.target.email.value;
                const password = e.target.password.value;
                handleLogin(email, password);
              }}
            >
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  defaultValue="admin@techcompare.com"
                  className="w-full border border-gray-300 rounded-md p-2"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Password
                </label>
                <input
                  type="password"
                  name="password"
                  defaultValue="admin123"
                  className="w-full border border-gray-300 rounded-md p-2"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600"
              >
                Sign In
              </button>
              <p className="text-center text-sm text-gray-600">
                Demo credentials: admin@techcompare.com / admin123
              </p>
            </form>
          </div>
        </div>
      )}

      <footer className="bg-gray-800 text-white mt-12">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">TechBuyWay</h3>
              <p className="text-gray-400">
                Your trusted source for tech product comparisons and reviews.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Categories</h4>
              <ul className="space-y-2">
                {categories.map((category) => (
                  <li key={category}>
                    <button
                      onClick={() => handleCategoryChange(category)}
                      className="text-gray-400 hover:text-white"
                    >
                      {category}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-gray-400 hover:text-white">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-400 hover:text-white">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-400 hover:text-white">
                    Privacy Policy
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact</h4>
              <ul className="space-y-2">
                <li className="text-gray-400">Email: info@techbuyway.com</li>
                <li className="text-gray-400">Phone: (555) 123-4567</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
            <p>© 2025 TechBuyWay. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;